#!/bin/sh
#autoconf
make -f build/autogen.mk
